declare module '@popperjs/core/dist/umd/popper.js' {
    // You can add more specific type definitions here if needed
    const Popper: any;
    export default Popper;
  }
  