import { useEffect, useState } from "react";
import { getBooks , deleteBook } from "../../services/books.service";
import { Link } from "react-router-dom";

function Home () {
    const [books, setBooks] = useState([])
    useEffect (()=> {
        getBooks()
        .then (res => setBooks(res.data))
    } , [])

    const onDeleteBook = (id) =>{
    const confirmDelete = window.confirm('Are you sure ? ')
    if (confirmDelete){
      deleteBook(id)
      .then(()=>{
        alert('Book Deleted Successfully ! ')
        setBooks(books.filter(book => book.id !== id));
        });
      }
    }

    return ( 
        <>
        <header className="bg-dark my-5 py-4 rounded-2 container mx-auto w-50 
        text-center text-light">
            <h2>Books</h2>
        </header>

        <section className="my-5 container text-center d-flex justify-content-center">
          <div className="row">
                      {  books.length > 0 &&
                            
                                books.map(book => (
                                  <div className="col-12 col-md-4 mb-4 d-flex justify-content-center" key={book.id}>
                                    <div className="card" style={{ width: '15rem' }}>
                                    <img className="card-img-top" src="Leather book cover template.jpeg" alt="Card image cap"/>
                                    <div className="card-body">
                                      <h5 className="card-title">#{book.id} <br/>{book.title}</h5>
                                      <p className="card-text">{book.desc}</p>
                                    </div>
                                    <ul className="list-group list-group-flush">
                                      <li className="list-group-item"><b>Price:</b> {book.price}</li>
                                      <li className="list-group-item"><b>Author:</b> {book.author}</li>
                                      
                                    </ul>
                                    <div className="card-body" style={{display:"flex"}}>
                                      <Link to={`/${book.id}`} className="btn btn-warning mx-1 ">Show</Link>
                                      <Link to={`/edit/${book.id}`} className="btn btn-success mx-1 ">Edit</Link>
                                      <button className="btn btn-danger mx-1" onClick={()=> onDeleteBook(book.id)}>Delete</button>
                                    </div>
                                  </div>
                                  </div>
                                )
                            )
                
                    
                     }
                </div>
        </section>
        
        </>
     );
}

export default Home ;