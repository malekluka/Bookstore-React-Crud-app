  import { useEffect, useState } from "react";
  import { useParams , useNavigate } from "react-router-dom"
  import { getBook } from "../../services/books.service";
  function Details() {
      const {id} = useParams();
      const [book, setBook] = useState({})
      const navigate = useNavigate();

      useEffect(()=> {
          getBook(id)
          .then(res => setBook(res.data))
      } , [])

      const redirectToHome = () =>{
          navigate('/')
      }
    return (
      <>
          <header className="bg-dark my-5 py-4 rounded-2 container mx-auto w-50 
              text-center text-light">
              <h2>Book Info</h2>
          </header>
          <div className="container d-flex justify-content-center">
            <div className="card text-center my-5 w-50 ">
                <div className="alert alert-success">
                    By : <strong>{book.author}</strong>
                </div>
                <div className="card-body">
                    <h4 className="card-title">{book.title}</h4>
                    <p className="card-text">{book.desc}</p>
                    <div className="container d-flex justify-content-center">
                        <div className="alert alert-success w-50" role="alert">
                            Price : <strong>{book.price}</strong>
                        </div>
                      </div>
                </div>
                <div className="container">
                <button type="button" className="btn btn-warning my-3"
                  onClick={redirectToHome}>Return To Home</button>
                </div>
            </div>
          </div>
      </>
    )
  }

  export default Details