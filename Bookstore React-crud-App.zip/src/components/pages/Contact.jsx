import { useState } from "react";
import emailjs from 'emailjs-com'; // Import EmailJS

function Contact() {
  const [emailData, setEmailData] = useState({
    email: '',
    name: '',
    message: '',
  });

  const [emailSent, setEmailSent] = useState(false);

  const handleEmailChange = (e) => {
    setEmailData({
      ...emailData,
      [e.target.name]: e.target.value
    });
  };

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs.sendForm(
      'service_v7imnxf',
      'template_k52yh76',
      e.target, // Passing the form element
      '3LkkT06RbKTFh9lJT'
    )
    .then((result) => {
        console.log(result.text);
        setEmailSent(true);
        setEmailData({
          email: '',
          name: '',
          message: '',
        });
      }, (error) => {
        console.log(error.text);
        alert('Failed to send email. Please try again.');
      });
  };

  return (
    <>
      <section className="my-5 container text-center border border-secondary rounded w-75 py-3">
        <h3>Contact Us</h3>
        <form onSubmit={sendEmail}>
          <div className="form-group">
            <label style={{ marginBottom: "8px" }} htmlFor="email">Recipient Email</label>
            <input
              type="email"
              id="email"
              name="email" // Matches {{email}} in the template
              className="form-control"
              style={{ marginBottom: "8px" }}
              value={emailData.email}
              onChange={handleEmailChange}
              required
            />
          </div>
          <div className="form-group">
            <label style={{ marginBottom: "8px" }} htmlFor="name">Sender Name</label>
            <input
              type="text"
              id="name"
              name="name" // Matches {{name}} in the template
              className="form-control"
              style={{ marginBottom: "8px" }}
              value={emailData.name}
              onChange={handleEmailChange}
              required
            />
          </div>
          <div className="form-group">
            <label style={{ marginBottom: "8px" }} htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message" // Matches {{message}} in the template
              className="form-control"
              value={emailData.message}
              onChange={handleEmailChange}
              required
            ></textarea>
          </div>
          <br />
          <button type="submit" className="btn btn-dark">Send Email</button>
        </form>
        {emailSent && <p className="mt-3">Your email has been sent successfully!</p>}
      </section>
    </>
  );
}

export default Contact;
