import { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { getBook, updateBook } from "../../services/books.service";
import { useNavigate } from "react-router-dom";

function Edit() {
    const { id } = useParams();
    const navigate = useNavigate();

    const [book, setBook] = useState({
        id: id,
        title: '',
        price: '',
        author: '',
        desc: ''
    });

    const originalBookRef = useRef(null);

    useEffect(() => {
        getBook(id)
            .then(res => {
                setBook(res.data);
                originalBookRef.current = res.data;
            });
    }, [id]);

    const handleSubmit = (event) => {
        event.preventDefault();
        const originalBook = originalBookRef.current;

        // Check if any field has been changed
        if (
            book.title === originalBook.title &&
            book.price === originalBook.price &&
            book.author === originalBook.author &&
            book.desc === originalBook.desc
        ) {
            alert('No changes detected. Please modify the values before submitting.');
            return;
        }

        if (book.title && book.price && book.author && book.desc) {
            updateBook(id, book)
                .then(() => {
                    alert('Book Updated Successfully !');
                    navigate('/');
                });
        } else {
            alert('Please fill out all fields.');
        }
    };

    return (
        <>
            <header className="bg-secondary my-5 py-4 rounded-2 container mx-auto w-50 text-center text-light">
                <h2>Edit Book</h2>
            </header>

            <section className="my-5 mx-auto w-50">
                <form onSubmit={handleSubmit}>
                    <div className="form-group my-2">
                        <label style={{ marginBottom: '8px' }} htmlFor="title">Book Title </label>
                        <input
                            type="text"
                            className="form-control"
                            id="title"
                            name="title"
                            onChange={e => setBook({ ...book, title: e.target.value })}
                            value={book.title}
                            placeholder="Enter book title"
                        />
                    </div>
                    <div className="form-group my-2">
                        <label style={{ marginBottom: '8px' }} htmlFor="price">Book Price</label>
                        <input
                            type="text"
                            className="form-control"
                            id="price"
                            name="price"
                            onChange={e => setBook({ ...book, price: e.target.value })}
                            value={book.price}
                            placeholder="Enter book price"
                        />
                    </div>
                    <div className="form-group my-2">
                        <label style={{ marginBottom: '8px' }} htmlFor="author">Book Author</label>
                        <input
                            type="text"
                            className="form-control"
                            id="author"
                            name="author"
                            onChange={e => setBook({ ...book, author: e.target.value })}
                            value={book.author}
                            placeholder="Enter book author"
                        />
                    </div>
                    <div className="form-group my-2">
                        <label style={{ marginBottom: '8px' }} htmlFor="desc">Book Description</label>
                        <textarea
                            className="form-control"
                            id="desc"
                            name="desc"
                            onChange={e => setBook({ ...book, desc: e.target.value })}
                            value={book.desc}
                            placeholder="Enter book description"
                        />
                    </div>
                    <input type="submit" value="Edit Book" className="btn btn-secondary my-2" />
                </form>
            </section>
        </>
    );
}

export default Edit;
