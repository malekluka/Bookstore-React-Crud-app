
function NotMatch() {
  return (
    <>
    <div className="alert alert-danger py-3 my-4 text-center mx-auto container w-50">
        Error 404 ! Page Not Found 😄
    </div>
    </>
  )
}

export default NotMatch;
