import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";
function Navbar () {
    return (
        <>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark py-3">
                <NavLink className="navbar-brand fw-bolder" to="/">
                    <i className="bi bi-code"></i> React Test
                </NavLink>
                    <div className="navbar-nav ms-auto">
                        <NavLink
                            className="nav-item nav-link mx-1 "
                            to="/"
                            end // This prop makes sure the 'Home' link is only active when exactly at '/' route
                        >
                            Home
                        </NavLink>
                        <NavLink
                            className="nav-item nav-link mx-1"
                            to="/create"
                        >
                            Create Book
                        </NavLink>
                        <NavLink
                            className="nav-item nav-link mx-1"
                            to="/contact"
                        >
                            Contact
                        </NavLink>
                    </div>
            </nav>
        </>
      );
}

export default Navbar ;