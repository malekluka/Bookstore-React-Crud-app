function Footer () {
    return ( 
    <>
    <footer className="bg-dark text-center text-white py-3 fs-5 mt-5">
        Copyright &copy; 2024 All Right Reserved
    </footer>
    </> 
    );
}

export default Footer;