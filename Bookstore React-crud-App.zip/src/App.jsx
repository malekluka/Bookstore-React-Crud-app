import Navbar from "./components/shared/Navbar";
import Footer from "./components/shared/Footer";
import { Routes,Route } from "react-router-dom";
import Home from "./components/pages/Home";
import Create from "./components/pages/Create";
import Details from "./components/pages/Details";
import Edit from "./components/pages/Edit";
import Contact from "./components/pages/Contact";
import NotMatch from "./components/error404/NotMatch";

function App(){
  return (
    <>
    <Navbar/>
    <Routes>
      <Route path="/" element ={<Home/>}/>
      <Route path="/create" element={<Create/>}/>
      <Route path="/:id" element = {<Details/>}/>
      <Route path="/edit/:id" element = {<Edit/>}/> 
      <Route path="/contact" element={<Contact/>}/>
      <Route path="*" element={<NotMatch/>}/>
    </Routes>
    <Footer/>
    
    </>
  )
}
export default App;